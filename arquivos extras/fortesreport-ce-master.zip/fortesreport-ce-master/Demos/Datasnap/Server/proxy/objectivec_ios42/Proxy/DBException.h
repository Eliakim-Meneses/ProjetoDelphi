//*******************************************************
//
//               Delphi DataSnap Framework
//
// Copyright(c) 1995-2011 Embarcadero Technologies, Inc.
//
//*******************************************************

#import <Foundation/Foundation.h>
#import <Foundation/NSException.h>
/**
 *@brief NSException discendant to raise error in proxy.
 */
@interface DBXException: NSException
@end


