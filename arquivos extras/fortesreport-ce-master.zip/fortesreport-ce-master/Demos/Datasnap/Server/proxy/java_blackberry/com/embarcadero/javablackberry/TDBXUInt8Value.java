//*******************************************************
//
//               Delphi DataSnap Framework
//
// Copyright(c) 1995-2011 Embarcadero Technologies, Inc.
//
//*******************************************************

package com.embarcadero.javablackberry;

/**
 * 
 * Wrap the UInt8 type and allows it to be null
 *
 */

public class TDBXUInt8Value extends DBXValue {

}
